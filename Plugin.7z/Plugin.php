<?php
Plugin Name: XIII
   Plugin URI: phelly741124221.wordpress.com
   description: >-
  a demo plugin
   Version: 1.2
   Author: Mr. Awesome
   Author URI: phelly741124221.wordpress.com
   License: GPL2
   
   class GoodPlugin {
 
    public function __construct() {
 
        load_plugin_textdomain( 'good-plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );
 
        add_action( 'wp_enqueue_scripts', array( $this, 'register_plugin_styles' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'register_plugin_scripts' ) );
 
        add_filter( 'the_content', array( $this, 'append_post_notification' ) );
 
    }
 
}
  ?> 
